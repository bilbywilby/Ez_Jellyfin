<div align="center">

# Jellyfin Production Infrastructure

**A hardware-accelerated, zero-trust Jellyfin deployment with decoupled async telemetry, staged readiness probing, and full Prometheus/Grafana observability.**

[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Jellyfin](https://img.shields.io/badge/jellyfin-10.9.10-00A4DC)](https://jellyfin.org)
[![Python](https://img.shields.io/badge/python-3.11%2B-3776AB)](probe/pyproject.toml)

</div>

---

This repository is not a Jellyfin quick-start. It is the operational layer that sits around Jellyfin once a deployment has outgrown a single Docker run command: a database that won't lock under concurrent writers, transcode pipelines that never silently fall back to the CPU, backups that don't balloon to gigabytes of scraped actor thumbnails, a reverse proxy that doesn't strangle WebSocket sessions or buffer away your time-to-first-byte, and a monitoring layer that distinguishes an HTTP 200 from an application that actually works.

## Architecture

```mermaid
flowchart LR
    Client -->|HTTPS| NGINX[nginx<br/>HTTP/2 · HTTP/3<br/>buffering off]
    NGINX --> JF[Jellyfin 10.9.10<br/>QSV / NVENC]
    JF --- DB[(SQLite WAL<br/>jellyfin.db · library.db)]
    JF -->|webhook events| WH[FastAPI sink<br/>async + backoff]
    WH --> SINK[(downstream telemetry)]
    PROBE[Readiness probe<br/>7-stage gate] -->|/System/Info · /Plugins · capability| JF
    PROBE -->|:9108/metrics| PROM[Prometheus]
    WH -->|:8001/metrics| PROM
    PROM --> GRAF[Grafana]
```

Jellyfin itself never talks to Prometheus or the probe directly; it only knows about its own database, its NFS mounts, and the webhook URLs it's configured to fire. The probe daemon and the webhook sink are independent processes that observe and react to Jellyfin from the outside, so a bug in either one can't take the media server down with it, and either can be redeployed, restarted, or rotated without touching the Jellyfin container at all.

## Design decisions that matter

The database runs SQLite in WAL mode with `synchronous=NORMAL`, a 2 GB memory-mapped I/O window, and incremental auto-vacuum, because the default rollback-journal mode serializes every write behind a single lock and falls over once a library crosses roughly 10⁵ items under concurrent scanning and playback-history writes. The full pragma set lives in `deployment/database_tuning.json` and is applied idempotently by `scripts/init-db.sh`.

Backups are scoped to seven explicit stateful paths — `system.xml`, `network.xml`, the two databases, collections, playlists, and plugins — rather than the whole `/config` volume, because `/config/data/metadata/People` accumulates one scraped image per actor across the entire library and will otherwise make every nightly snapshot larger and slower than the last for no operational benefit. `scripts/backup.sh` runs a `VACUUM` before archiving and compresses with zstd; the exclusion list is enforced in code, not left as a one-time manual step someone forgets after the next library import.

Hardware transcoding is configured for zero-copy operation on both Intel QSV (`iHD` driver, `hwaccel_output_format qsv` end to end) and NVIDIA NVENC (`hwaccel cuda` with `extra_hw_frames` tuned for buffering), specifically because Jellyfin's UI hides the underlying ffmpeg flags and will silently fall back to CPU tone-mapping if the hardware path isn't fully wired — a failure mode that shows up as "the server got slow" with no obvious cause. `deployment/hardware_transcode_profiles.json` pins the explicit flag set so that doesn't happen.

| | Intel QSV | NVIDIA NVENC |
|---|---|---|
| Driver | `iHD` (not legacy `i965`) | `nvidia-container-toolkit` |
| Decode path | `-hwaccel qsv -hwaccel_output_format qsv` | `-hwaccel cuda -hwaccel_output_format cuda` |
| Codecs | H.264, HEVC, AV1 | H.264, HEVC |
| Tone-mapping | `vpp_qsv` hardware filter | `scale_cuda` hardware filter |
| Container requirement | `/dev/dri/renderD128` device passthrough | `NVIDIA_DRIVER_CAPABILITIES=compute,video,utility` |

The reverse proxy disables `proxy_buffering` outright and sets hour-long read/send timeouts, because Jellyfin holds long-lived WebSocket connections for session sync and remote control, and a buffering proxy will queue an entire transcoded segment before forwarding a byte of it — which looks identical to network packet loss from the client's perspective but is actually the proxy doing exactly what it was told to do.

The probe daemon treats a `200 OK` from a plugin's configuration endpoint as proof that routing and the controller binding work, not as proof the plugin is functionally healthy — those are different claims, and conflating them is how a deployment gate passes while the auth provider it's supposed to validate has silently failed to register. The gate runs seven stages in order: transport reachability, authentication, plugin discovery by GUID (schema-tolerant — a missing or unexpected `Status` field warns rather than hard-fails, since Jellyfin's API shape isn't a stable contract across versions), administrative state, liveness, a plugin-defined capability check, and a negative test confirming the server still rejects unauthenticated requests. Only after all seven does it report healthy, and it exports per-stage latency and failure-type counters to Prometheus rather than a single up/down bit.

## Repository layout

```
docker-compose.yml          Root stack: jellyfin, webhook sidecar, probe, prometheus, nginx
.env.example                 Copy to .env and fill in
config/jellyfin/             config.json (client), logging.json (structured Serilog)
config/nginx/                Reverse proxy: HTTP/2, no buffering, /socket upgrade
deployment/                  Declarative schemas — backup, ingress, metrics, transcode,
                              OIDC, SQLite tuning, security, library naming, ECS task def
sidecar/                     FastAPI webhook ingestion microservice
probe/                       Standalone packaged daemon — 7-stage readiness gate,
                              Prometheus exporter, encrypted credential storage
scripts/                     deploy.sh, init-db.sh, backup.sh, healthcheck.py,
                              install-backup-cron.sh
monitoring/                  Prometheus scrape config, alert rules, Grafana dashboard
```

## Bringing it up

```bash
cp .env.example .env
$EDITOR .env   # JELLYFIN_API_KEY, NFS_MOVIES, NFS_TV, JELLYFIN_OIDC_CLIENT_SECRET
./scripts/deploy.sh
```

`deploy.sh` pulls images, brings the stack up, polls the Jellyfin container healthcheck for up to 150 seconds, then applies the WAL pragmas via `init-db.sh` once the databases actually exist on disk. Install the nightly backup with `./scripts/install-backup-cron.sh`, which writes a crontab entry at 02:00 matching the cadence declared in `deployment/backup_policy.json` — it doesn't run as a background loop inside a container, so it survives a `docker compose down` and doesn't depend on the stack being up at the scheduled hour.

`PUBLISHED_SERVER_URL` is the externally reachable HTTPS origin Jellyfin advertises to clients for casting and remote access; it has to match what's actually in front of nginx or Chromecast-style discovery breaks. `JELLYFIN_API_KEY` and the optional `JELLYFIN_API_KEY_BACKUP` are consumed by the probe daemon, not by Jellyfin itself — the backup key exists so a key rotation has a window where both the old and new key authenticate before the old one is revoked in the Jellyfin dashboard, rather than forcing a synchronized cutover. `JELLYFIN_PLUGIN_ID` and `JELLYFIN_PROVIDER_NAME` tell the probe which plugin GUID to validate and which auth provider name to look for in `/Authentication/Providers` during the capability stage.

## The probe daemon

`probe/` ships as its own installable Python package (`pyproject.toml`, `Makefile`, pre-commit, GitHub Actions CI) rather than a script bolted onto this repo, because it's meant to be deployable independently of whether you're running Jellyfin via this exact compose file. It runs the health check every 15 seconds and the full readiness gate every 60, exporting `jellyfin_probe_state` (0 unknown, 1 healthy, 2 degraded, 3 unhealthy), per-stage `jellyfin_probe_latency_seconds`, and failure counters keyed by exception type — so a Grafana panel can distinguish "the network is fine but the plugin is misconfigured" from "Jellyfin itself is down" without grepping logs.

Credential handling went through three iterations during design and the current state is intentional: the API key comes from `JELLYFIN_API_KEY` when set, and is persisted into an AES-encrypted `keyrings.cryptfile` store gated by `KEYRING_PASSWORD_FILE`; if the env var is ever absent on a restart, the daemon recovers the last-known-good key from that encrypted store instead of failing to start. The store's own encryption password is generated with `secrets.token_urlsafe(32)` on first run and written with `0600` permissions — it is never prompted for interactively, because this daemon runs under systemd with no controlling TTY, and `getpass()` reading from a closed stdin raises `EOFError` and crashes startup. Deployment options are `systemd/jellyfin-probe.service` (host-based, `ProtectSystem=strict`, capability-dropped) or `docker/Dockerfile` plus `compose/docker-compose.yml` for a containerized sidecar with bundled Prometheus.

## Security posture

The Jellyfin container runs with `cap_drop: ALL` and only `SYS_ADMIN`, `SETUID`, and `SETGID` added back for the QSV device path and process management Jellyfin actually needs — not the default unbounded capability set most container images run with. Media mounts are read-only NFSv4; nothing in this stack can write into the library. `deployment/security_hardening.json` enforces a 14-character minimum password, a 5-attempt lockout with a 30-minute cooldown, and 90-day token expiry, and `deployment/identity_provisioning.json` provides the OIDC claim-mapping template for binding to Authentik, Authelia, or any standards-compliant IdP so credentials live in one place instead of being fragmented across every service in the homelab.

## License

MIT. See [LICENSE](LICENSE).
