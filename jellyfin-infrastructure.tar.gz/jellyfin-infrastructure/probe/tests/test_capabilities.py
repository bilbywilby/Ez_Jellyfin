from jellyfin_probe.capabilities import auth_not_bypassed, build_capability


def test_auth_not_bypassed_is_callable() -> None:
    assert callable(auth_not_bypassed)


def test_build_capability_returns_callable() -> None:
    cap = build_capability("TestProvider")
    assert callable(cap)
