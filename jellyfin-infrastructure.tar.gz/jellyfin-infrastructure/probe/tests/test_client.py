from jellyfin_probe.client import JellyfinClient


def test_client_strips_trailing_slash() -> None:
    client = JellyfinClient("http://localhost:8096/", "abc")
    assert client.base_url == "http://localhost:8096"


def test_client_sets_auth_header() -> None:
    client = JellyfinClient("http://localhost:8096", "mykey")
    assert client.headers["X-Emby-Token"] == "mykey"
