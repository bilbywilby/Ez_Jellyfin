# Jellyfin Probe Daemon

Continuous Jellyfin plugin readiness checks with Prometheus metrics.

## Architecture

Three-tier monitoring: fast `/health` checks every 15s, staged plugin readiness checks every 60s. Readiness runs a seven-stage gate (transport, auth, discovery, administrative state, liveness, capability, negative-test) rather than trusting a single 200 OK as proof of functional health.

## Commands

```
make dev
make test
make lint
make typecheck
make run
make docker-build
make docker-run
```

## Environment

See `env/jellyfin-probe.env.example`. `JELLYFIN_API_KEY_BACKUP` enables zero-downtime dual-key rotation — set it during a key rotation window, then remove once cutover is confirmed.

## Deployment

- `systemd/jellyfin-probe.service` — host-based deployment with hardened sandboxing (`ProtectSystem=strict`, `NoNewPrivileges`).
- `docker/Dockerfile` + `compose/docker-compose.yml` — containerized deployment with bundled Prometheus.

Metrics exposed on `:9108/metrics`: `jellyfin_probe_state`, `jellyfin_probe_success_total`, `jellyfin_probe_failure_total`, `jellyfin_probe_latency_seconds`, `jellyfin_probe_last_success_timestamp`.
