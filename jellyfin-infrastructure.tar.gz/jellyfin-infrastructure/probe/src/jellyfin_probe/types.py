from dataclasses import dataclass
from typing import Protocol

from .client import JellyfinClient  # noqa: F401 — re-exported for Protocol use


class CapabilityCheck(Protocol):
    def __call__(self, client: "JellyfinClient") -> None: ...


@dataclass(frozen=True)
class ProbeConfig:
    base_url: str
    api_key: str
    plugin_id: str
    provider_name: str
    metrics_port: int = 9108
    health_interval: int = 15
    readiness_interval: int = 60
    unhealthy_after: int = 3
