from typing import Any, Callable, Dict

from .client import JellyfinClient
from .exceptions import (
    JellyfinAuthError,
    JellyfinTransportError,
    PluginAdministrativeStateError,
    PluginDiscoveryError,
    PluginLivenessError,
)


class PluginReadinessProbe:
    """
    Seven-stage readiness gate:
      1-2. Transport + Auth
      3.   Plugin discovery
      4.   Administrative state (not disabled)
      5.   Liveness (config endpoint responds)
      6-7. Capability (plugin-defined behavioral contract)
    """

    def __init__(
        self,
        client: JellyfinClient,
        plugin_id: str,
        capability: Callable[[JellyfinClient], None],
    ) -> None:
        self.client = client
        self.plugin_id = plugin_id
        self.capability = capability

    def check_server_and_auth(self) -> None:
        r = self.client.get("/System/Info")
        if r.status_code == 401:
            raise JellyfinAuthError("Invalid API key")
        if r.status_code >= 400:
            raise JellyfinTransportError(f"Server error {r.status_code}")

    def get_plugin(self) -> Dict[str, Any]:
        r = self.client.get("/Plugins")
        if r.status_code != 200:
            raise PluginDiscoveryError(f"Cannot list plugins: {r.status_code}")
        for p in r.json():
            if str(p.get("Id")) == self.plugin_id:
                return p  # type: ignore[return-value]
        raise PluginDiscoveryError(f"Plugin {self.plugin_id} not found in registry")

    def check_not_disabled(self, plugin: Dict[str, Any]) -> None:
        status = plugin.get("Status")
        if isinstance(status, str) and status.lower() in {"disabled", "inactive"}:
            raise PluginAdministrativeStateError(f"Plugin explicitly disabled: {status}")
        if status in (False, 0):
            raise PluginAdministrativeStateError("Plugin disabled (boolean/zero state)")

    def check_liveness(self) -> None:
        r = self.client.get(f"/Plugins/{self.plugin_id}/Configuration")
        if r.status_code != 200:
            raise PluginLivenessError(f"Configuration endpoint failed: {r.status_code}")

    def run(self) -> None:
        self.check_server_and_auth()
        plugin = self.get_plugin()
        self.check_not_disabled(plugin)
        self.check_liveness()
        self.capability(self.client)
