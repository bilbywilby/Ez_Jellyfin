import os
import secrets
from pathlib import Path
from typing import Optional

import keyring


class TokenStore:
    SERVICE_NAME = "jellyfin-probe-daemon"
    USERNAME = "probe-token"

    @staticmethod
    def configure_cryptfile_backend(password_file: str) -> None:
        """
        Configure the keyrings.cryptfile backend.

        This runs inside a long-lived daemon process with no controlling TTY
        (systemd Type=simple, Docker entrypoint). Prompting via getpass() would
        raise EOFError on first read and crash startup, so on first run we
        generate a random 256-bit encryption password and persist it with
        0600 permissions instead of asking a human who isn't there.
        """
        import keyrings.cryptfile  # type: ignore[import]

        password_path = Path(password_file)
        if not password_path.exists():
            password_path.parent.mkdir(parents=True, exist_ok=True)
            random_password = secrets.token_urlsafe(32)
            password_path.write_text(random_password)
            os.chmod(password_file, 0o600)

        password = password_path.read_text().strip()
        keyring.set_keyring(keyrings.cryptfile.CryptFileKeyring(password))

    def save_token(self, token: str) -> None:
        keyring.set_password(self.SERVICE_NAME, self.USERNAME, token)

    def get_token(self) -> Optional[str]:
        return keyring.get_password(self.SERVICE_NAME, self.USERNAME)

    def delete_token(self) -> None:
        try:
            keyring.delete_password(self.SERVICE_NAME, self.USERNAME)
        except keyring.errors.PasswordDeleteError:
            pass
