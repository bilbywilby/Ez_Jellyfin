import httpx

from .exceptions import JellyfinTransportError


class JellyfinClient:
    def __init__(self, base_url: str, api_key: str, timeout: float = 5.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.headers = {"X-Emby-Token": api_key}
        self.client = httpx.Client(timeout=timeout)

    def get(self, path: str, auth: bool = True) -> httpx.Response:
        try:
            return self.client.get(
                f"{self.base_url}{path}",
                headers=self.headers if auth else {},
            )
        except httpx.RequestError as e:
            raise JellyfinTransportError(str(e)) from e
