import json
import time
from dataclasses import dataclass, field
from typing import Callable, List

from prometheus_client import Counter, Gauge, Histogram, start_http_server

PROBE_SUCCESS = Counter("jellyfin_probe_success_total", "Successful probe runs", ["probe"])
PROBE_FAILURE = Counter(
    "jellyfin_probe_failure_total", "Failed probe runs", ["probe", "error_type"]
)
PROBE_LATENCY = Histogram("jellyfin_probe_latency_seconds", "Probe latency", ["probe"])
PROBE_STATE = Gauge("jellyfin_probe_state", "0=unknown 1=healthy 2=degraded 3=unhealthy", ["probe"])
PROBE_LAST_SUCCESS = Gauge("jellyfin_probe_last_success_timestamp", "Last success epoch", ["probe"])
PROBE_LAST_RUN = Gauge("jellyfin_probe_last_run_timestamp", "Last run epoch", ["probe"])

STATE_MAP = {"unknown": 0, "healthy": 1, "degraded": 2, "unhealthy": 3}


@dataclass
class ProbeJob:
    name: str
    interval: int
    probe: Callable[[], None]
    fail_count: int = field(default=0, init=False)
    state: str = field(default="unknown", init=False)
    last_run: float = field(default=0.0, init=False)


class ProbeSupervisor:
    def __init__(
        self,
        jobs: List[ProbeJob],
        listen_port: int = 9108,
        unhealthy_after: int = 3,
    ) -> None:
        self.jobs = jobs
        self.listen_port = listen_port
        self.unhealthy_after = unhealthy_after
        self.stop = False

    def _set_state(self, job: ProbeJob, state: str) -> None:
        job.state = state
        PROBE_STATE.labels(job.name).set(STATE_MAP[state])

    def _tick_job(self, job: ProbeJob) -> None:
        now = time.time()
        if now - job.last_run < job.interval:
            return

        job.last_run = now
        PROBE_LAST_RUN.labels(job.name).set(now)
        start = time.perf_counter()

        try:
            job.probe()
            elapsed = time.perf_counter() - start
            PROBE_LATENCY.labels(job.name).observe(elapsed)
            PROBE_SUCCESS.labels(job.name).inc()
            PROBE_LAST_SUCCESS.labels(job.name).set(now)
            job.fail_count = 0
            self._set_state(job, "healthy")
            print(json.dumps({"probe": job.name, "state": "healthy", "latency_ms": round(elapsed * 1000, 2)}))
        except Exception as e:
            elapsed = time.perf_counter() - start
            PROBE_LATENCY.labels(job.name).observe(elapsed)
            PROBE_FAILURE.labels(job.name, type(e).__name__).inc()
            job.fail_count += 1
            state = "degraded" if job.fail_count < self.unhealthy_after else "unhealthy"
            self._set_state(job, state)
            print(
                json.dumps(
                    {
                        "probe": job.name,
                        "state": state,
                        "error": type(e).__name__,
                        "detail": str(e),
                    }
                )
            )

    def run(self) -> None:
        start_http_server(self.listen_port)
        for job in self.jobs:
            self._set_state(job, "unknown")
        print(json.dumps({"event": "metrics_started", "port": self.listen_port}))

        while not self.stop:
            for job in self.jobs:
                self._tick_job(job)
            time.sleep(1)
