class JellyfinError(Exception):
    pass


class JellyfinTransportError(JellyfinError):
    pass


class JellyfinAuthError(JellyfinError):
    pass


class PluginDiscoveryError(JellyfinError):
    pass


class PluginAdministrativeStateError(JellyfinError):
    pass


class PluginLivenessError(JellyfinError):
    pass


class PluginReadinessError(JellyfinError):
    pass
