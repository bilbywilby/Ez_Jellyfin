import os
import signal
from typing import Optional

from .capabilities import build_capability
from .client import JellyfinClient
from .probes import PluginReadinessProbe
from .supervisor import ProbeJob, ProbeSupervisor
from .token_store import TokenStore


def _build_client(base_url: str, api_key: str, api_key_backup: Optional[str]) -> JellyfinClient:
    """
    Dual-key rotation: try primary, fall back to backup on 401.
    Backup key exists only during the rotation window.
    """
    client = JellyfinClient(base_url, api_key)
    if api_key_backup:
        probe = client.get("/System/Info")
        if probe.status_code == 401:
            client = JellyfinClient(base_url, api_key_backup)
    return client


def main() -> None:
    base_url = os.environ.get("JELLYFIN_URL", "http://localhost:8096")
    api_key = os.environ.get("JELLYFIN_API_KEY", "")
    api_key_backup: Optional[str] = os.environ.get("JELLYFIN_API_KEY_BACKUP") or None
    plugin_id = os.environ.get("JELLYFIN_PLUGIN_ID", "")
    provider_name = os.environ.get("JELLYFIN_PROVIDER_NAME", "MyPlugin")
    metrics_port = int(os.environ.get("METRICS_PORT", "9108"))
    password_file = os.environ.get(
        "KEYRING_PASSWORD_FILE", "/var/lib/jellyfin-probe/keyring-password"
    )

    if password_file:
        TokenStore.configure_cryptfile_backend(password_file)
        store = TokenStore()
        if api_key:
            # Env var is authoritative when present — persist it so a restart
            # without EnvironmentFile access (e.g. credential rotation gap)
            # can still recover the last-known-good key.
            store.save_token(api_key)
        else:
            recovered = store.get_token()
            if recovered:
                api_key = recovered

    if not api_key:
        raise RuntimeError(
            "No JELLYFIN_API_KEY provided and no key recoverable from the "
            "encrypted keyring at the configured KEYRING_PASSWORD_FILE."
        )

    client = _build_client(base_url, api_key, api_key_backup)
    capability = build_capability(provider_name)
    readiness = PluginReadinessProbe(client, plugin_id, capability)

    jobs = [
        ProbeJob("health", 15, lambda: client.get("/health")),
        ProbeJob("readiness", 60, readiness.run),
    ]

    supervisor = ProbeSupervisor(jobs, listen_port=metrics_port)

    def _stop(sig: int, frame: object) -> None:
        supervisor.stop = True

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    supervisor.run()
