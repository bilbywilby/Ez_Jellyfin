from .client import JellyfinClient
from .exceptions import PluginReadinessError


def auth_provider_capability(provider_name: str):
    def verify(client: JellyfinClient) -> None:
        r = client.get("/Authentication/Providers")
        if r.status_code != 200:
            raise PluginReadinessError(f"Provider endpoint failed: {r.status_code}")
        providers = r.json()
        if not any(provider_name in str(p) for p in providers):
            raise PluginReadinessError(f"Auth provider not registered: {provider_name}")

    return verify


def auth_not_bypassed(client: JellyfinClient) -> None:
    """Negative test — unauthenticated request must return 401."""
    r = client.get("/System/Info", auth=False)
    if r.status_code != 401:
        raise PluginReadinessError(
            f"Auth enforcement absent — expected 401, got {r.status_code}"
        )


def build_capability(provider_name: str):
    def verify(client: JellyfinClient) -> None:
        auth_provider_capability(provider_name)(client)
        auth_not_bypassed(client)

    return verify
