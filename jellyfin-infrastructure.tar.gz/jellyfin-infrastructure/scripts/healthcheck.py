#!/usr/bin/env python3
"""
Async Jellyfin health probe with exponential backoff.
Validates real API responsiveness — not just TCP port reachability.
"""
import asyncio
import os
import sys
from typing import Any, Final

import httpx

API_URL: Final[str] = os.getenv("JELLYFIN_API_URL", "http://127.0.0.1:8096")
API_KEY: Final[str] = os.getenv("JELLYFIN_API_KEY", "")
MAX_RETRIES: Final[int] = 3
INITIAL_DELAY: Final[float] = 1.0


async def evaluate_subsystem_health(client: httpx.AsyncClient) -> bool:
    headers: dict[str, str] = {
        "Authorization": f'MediaBrowser Token="{API_KEY}"',
        "Accept": "application/json",
    }
    try:
        response = await client.get(f"{API_URL}/System/Info", headers=headers, timeout=5.0)
        if response.status_code != 200:
            return False
        system_info: dict[str, Any] = response.json()
        return bool(system_info.get("Version"))
    except (httpx.RequestError, ValueError):
        return False


async def main() -> None:
    if not API_KEY:
        sys.stderr.write("JELLYFIN_API_KEY is unset.\n")
        sys.exit(1)

    delay: float = INITIAL_DELAY
    async with httpx.AsyncClient() as client:
        for attempt in range(1, MAX_RETRIES + 1):
            if await evaluate_subsystem_health(client):
                sys.stdout.write("Jellyfin subsystems nominal.\n")
                sys.exit(0)
            sys.stderr.write(
                f"Health probe failed (attempt {attempt}/{MAX_RETRIES}). "
                f"Retrying in {delay}s...\n"
            )
            if attempt < MAX_RETRIES:
                await asyncio.sleep(delay)
                delay *= 2.0

    sys.stderr.write("Jellyfin failed health evaluation after all retries.\n")
    sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
