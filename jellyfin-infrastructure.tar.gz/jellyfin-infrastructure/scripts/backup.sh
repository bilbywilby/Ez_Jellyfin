#!/usr/bin/env bash
# Stateful-only backup of Jellyfin config — implements backup_policy.json.
# Excludes: /cache, /log, /transcodes, /data/metadata/People
set -euo pipefail

CONFIG_ROOT="${JELLYFIN_CONFIG_ROOT:-/var/srv/jellyfin/config}"
BACKUP_DEST="${BACKUP_DEST:-/var/backups/jellyfin}"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
TIMESTAMP=$(date +"%Y%m%dT%H%M%S")
ARCHIVE="${BACKUP_DEST}/jellyfin-backup-${TIMESTAMP}.tar.zst"

mkdir -p "${BACKUP_DEST}"

echo "[$(date -u +%FT%TZ)] Running pre-backup VACUUM..."
sqlite3 "${CONFIG_ROOT}/data/jellyfin.db" "VACUUM;"
sqlite3 "${CONFIG_ROOT}/data/library.db"  "VACUUM;" 2>/dev/null || true

echo "[$(date -u +%FT%TZ)] Creating stateful archive: ${ARCHIVE}"
tar \
  --exclude="${CONFIG_ROOT}/cache" \
  --exclude="${CONFIG_ROOT}/log" \
  --exclude="${CONFIG_ROOT}/transcodes" \
  --exclude="${CONFIG_ROOT}/data/metadata/People" \
  -c \
  "${CONFIG_ROOT}/config/system.xml" \
  "${CONFIG_ROOT}/config/network.xml" \
  "${CONFIG_ROOT}/data/jellyfin.db" \
  "${CONFIG_ROOT}/data/displaypreferences.db" \
  "${CONFIG_ROOT}/data/collections" \
  "${CONFIG_ROOT}/data/playlists" \
  "${CONFIG_ROOT}/plugins" \
  2>/dev/null \
  | zstd -3 -o "${ARCHIVE}"

echo "[$(date -u +%FT%TZ)] Archive created: ${ARCHIVE} ($(du -sh "${ARCHIVE}" | cut -f1))"

echo "[$(date -u +%FT%TZ)] Pruning backups older than ${RETENTION_DAYS} days..."
find "${BACKUP_DEST}" -name "jellyfin-backup-*.tar.zst" -mtime "+${RETENTION_DAYS}" -delete

echo "[$(date -u +%FT%TZ)] Backup complete."
