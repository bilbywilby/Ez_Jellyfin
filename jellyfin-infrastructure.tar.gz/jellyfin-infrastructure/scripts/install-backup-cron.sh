#!/usr/bin/env bash
# Installs the nightly backup cron entry (02:00) per backup_policy.json's frequency.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CRON_LINE="0 2 * * * ${SCRIPT_DIR}/backup.sh >> /var/log/jellyfin-backup.log 2>&1"

( crontab -l 2>/dev/null | grep -vF "${SCRIPT_DIR}/backup.sh" ; echo "${CRON_LINE}" ) | crontab -

echo "Installed cron entry:"
echo "  ${CRON_LINE}"
