#!/usr/bin/env bash
# Applies WAL mode and performance pragmas to both Jellyfin SQLite databases.
# Run once after initial Jellyfin startup before production traffic begins.
set -euo pipefail

CONFIG_DATA="${1:-/var/srv/jellyfin/config/data}"
DBS=("jellyfin.db" "library.db")

PRAGMAS=(
  "PRAGMA journal_mode=WAL;"
  "PRAGMA synchronous=NORMAL;"
  "PRAGMA locking_mode=NORMAL;"
  "PRAGMA cache_size=-64000;"
  "PRAGMA mmap_size=2147483648;"
  "PRAGMA temp_store=MEMORY;"
  "PRAGMA busy_timeout=10000;"
  "PRAGMA page_size=4096;"
  "PRAGMA auto_vacuum=INCREMENTAL;"
)

for db in "${DBS[@]}"; do
  TARGET="${CONFIG_DATA}/${db}"
  if [[ ! -f "${TARGET}" ]]; then
    echo "WARN: ${TARGET} not found — skipping (Jellyfin may not have run yet)."
    continue
  fi

  echo "Applying WAL pragmas to ${TARGET}..."
  for pragma in "${PRAGMAS[@]}"; do
    sqlite3 "${TARGET}" "${pragma}"
  done

  echo "Running VACUUM on ${TARGET}..."
  sqlite3 "${TARGET}" "VACUUM;"

  echo "Done: ${TARGET}"
done

echo "All databases configured."
