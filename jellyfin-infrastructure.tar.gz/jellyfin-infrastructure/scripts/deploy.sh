#!/usr/bin/env bash
# End-to-end deployment: bring up stack, apply DB pragmas, verify health.
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."

if [[ ! -f .env ]]; then
  echo "ERROR: .env not found. Copy .env.example to .env and fill in values first." >&2
  exit 1
fi

echo "[1/4] Pulling images..."
docker compose pull

echo "[2/4] Starting stack..."
docker compose up -d

echo "[3/4] Waiting for Jellyfin to report healthy..."
for _ in $(seq 1 30); do
  status=$(docker inspect --format='{{.State.Health.Status}}' jellyfin-production 2>/dev/null || echo "starting")
  if [[ "${status}" == "healthy" ]]; then
    echo "Jellyfin is healthy."
    break
  fi
  sleep 5
done

echo "[4/4] Applying SQLite WAL pragmas..."
./scripts/init-db.sh "${JELLYFIN_CONFIG_ROOT:-/var/srv/jellyfin/config/data}" || \
  echo "WARN: init-db.sh failed — run it manually once Jellyfin has created its databases."

echo "Deployment complete. Services:"
docker compose ps
