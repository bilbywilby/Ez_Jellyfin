"""
Jellyfin webhook ingestion sidecar.
FastAPI + Pydantic v2 + HTTPX with exponential backoff forwarding.
Thread-safe in-flight session tracking via asyncio.Lock.
"""
import asyncio
import logging
import os
import sys
from datetime import datetime
from typing import Any, Optional

import httpx
from fastapi import FastAPI, HTTPException, Request, status
from pydantic import BaseModel, ConfigDict, Field

logging.basicConfig(
    level=logging.INFO,
    format='{"timestamp":"%(asctime)s","level":"%(levelname)s","module":"%(module)s","message":%(message)s}',
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("jellyfin_sink")

app = FastAPI(
    title="Jellyfin State Synchronization Ingestion Engine",
    version="1.0.0",
)


class PlaybackItem(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str = Field(..., alias="Name")
    item_type: str = Field(..., alias="Type")
    run_time_ticks: int = Field(..., alias="RunTimeTicks")


class JellyfinWebhookPayload(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    notification_type: str = Field(..., alias="NotificationType")
    utc_timestamp: str = Field(
        default_factory=lambda: datetime.utcnow().isoformat(),
        alias="UtcTimestamp",
    )
    user_name: str = Field(..., alias="UserName")
    user_id: str = Field(..., alias="UserId")
    device_name: str = Field(..., alias="DeviceName")
    item_details: PlaybackItem = Field(..., alias="Item")
    is_automated: bool = Field(default=False)


class InflightTranscodeTracker:
    def __init__(self) -> None:
        self._active_sessions: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()

    async def register_session(self, session_id: str, metadata: dict[str, Any]) -> None:
        async with self._lock:
            self._active_sessions[session_id] = {
                **metadata,
                "registered_at": datetime.utcnow().isoformat(),
            }
            logger.info(f'"Session registered: {session_id}"')

    async def evict_session(self, session_id: str) -> Optional[dict[str, Any]]:
        async with self._lock:
            evicted = self._active_sessions.pop(session_id, None)
            if evicted:
                logger.info(f'"Session evicted: {session_id}"')
            return evicted


transcode_tracker = InflightTranscodeTracker()

DOWNSTREAM_URL = os.getenv(
    "DOWNSTREAM_TELEMETRY_URL", "http://monitoring.internal.network/api/v1/telemetry"
)


async def forward_to_downstream_sink(payload: dict[str, Any], endpoint_url: str) -> None:
    max_retries = 3
    backoff_factor = 2.0
    async with httpx.AsyncClient(timeout=5.0) as client:
        for attempt in range(max_retries):
            try:
                response = await client.post(endpoint_url, json=payload)
                if response.status_code == 200:
                    logger.info(f'"Downstream sync confirmed on attempt {attempt + 1}."')
                    return
                logger.warning(f'"Downstream bad status: {response.status_code}. Retrying."')
            except httpx.RequestError as exc:
                logger.error(f'"Transport failure during downstream routing: {str(exc)}."')
            if attempt < max_retries - 1:
                await asyncio.sleep(backoff_factor**attempt)
    logger.error(f'"Dead letter: failed to sync payload after {max_retries} attempts."')


@app.post("/webhook/v1/ingest", status_code=status.HTTP_202_ACCEPTED)
async def handle_jellyfin_webhook(request: Request) -> dict[str, str]:
    try:
        raw_json = await request.json()
    except Exception as exc:
        logger.error(f'"Malformed JSON: {str(exc)}."')
        raise HTTPException(status_code=400, detail="Invalid application/json format")

    try:
        validated_payload = JellyfinWebhookPayload.model_validate(raw_json)
    except Exception as validation_exc:
        logger.error(f'"Schema validation failed: {str(validation_exc)}."')
        raise HTTPException(
            status_code=422,
            detail=f"Schema constraint failure: {str(validation_exc)}",
        )

    session_key = f"{validated_payload.user_id}_{validated_payload.device_name}"

    if validated_payload.notification_type in {"PlaybackStart", "PlaybackProgress"}:
        asyncio.create_task(
            transcode_tracker.register_session(
                session_id=session_key,
                metadata=validated_payload.model_dump(by_alias=True),
            )
        )
    elif validated_payload.notification_type == "PlaybackStop":
        asyncio.create_task(transcode_tracker.evict_session(session_id=session_key))

    asyncio.create_task(
        forward_to_downstream_sink(
            payload=validated_payload.model_dump(by_alias=True),
            endpoint_url=DOWNSTREAM_URL,
        )
    )

    return {"status": "accepted", "tracking_id": session_key}
